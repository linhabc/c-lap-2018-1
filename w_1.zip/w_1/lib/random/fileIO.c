#ifndef __FILE_I_O
#define __FILE_I_O

#include <stdio.h>



#endif
